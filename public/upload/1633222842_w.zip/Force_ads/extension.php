﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v2.3.3(+)                         ##
##                      http://www.krhost.ga                       ##
##                 e-mail: admin@kariya-host.com                   ##
##                                                                 ##
##                       copyright (c) 2021                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################

$extension = array(
/* Description Extension */
"name" => "Force ads to appear",
"description" => "فرض ظهور الإعلانات لمن يستعمل السكربت على إستضافة مجانية .",
"version" => "1.0",
"latest version" => "<script language=\"javascript\" src=\"http://apikariya.gq/version/Force_ads.php?v=1-0\"></script>",
"v-myads" => "MyAds v2.3.3(+)",
"devlope by" => "<a href=\"http://www.krhost.ga/\" target=\"_blank\">Kariya Host</a>",

/* Extension */
"install" => "install.php",
"uninstall" => "uninstall.php",

)
  ?>
