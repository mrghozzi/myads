﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v2.3.x                            ##
##                      http://www.krhost.ga                       ##
##                 e-mail: admin@kariya-host.com                   ##
##                                                                 ##
##                       copyright (c) 2021                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################

if($_POST['install']=="install"){
  include_once '../../../dbconfig.php';
    //  setting
   $stmt = $db_con->prepare("SELECT *  FROM setting   " );
 $stmt->execute();
 $stt=$stmt->fetch(PDO::FETCH_ASSOC);
  $url_site   = $stt['url'];

  //  options
  $name      = "Force ads to appear";
  $o_valuer  = "1";
  $o_type    = "plugins";
  $o_mode    = "kr_Force_ads";
  $ostmsbs = $db_con->prepare(" INSERT INTO options  (name,o_valuer,o_type,o_parent,o_order,o_mode)
            VALUES (:name,:o_valuer,:o_type,0,0,:o_mode) ");
	     $ostmsbs->bindParam(":name", $name);
            $ostmsbs->bindParam(":o_valuer", $o_valuer);
            $ostmsbs->bindParam(":o_type", $o_type);
            $ostmsbs->bindParam(":o_mode", $o_mode);
            $ostmsbs->execute();
  $name      = "Force ads to appear";
  $o_valuer  = "<iframe src=\"{$url_site}\" style=\"visibility: hidden;\" width=\"1\" height=\"1\"></iframe>";
  $o_type    = "extensions_code";

  $ostmsbu = $db_con->prepare(" INSERT INTO options  (name,o_valuer,o_type,o_parent,o_order,o_mode)
            VALUES (:name,:o_valuer,:o_type,0,0,:o_mode) ");
	     $ostmsbu->bindParam(":name", $name);
            $ostmsbu->bindParam(":o_valuer", $o_valuer);
            $ostmsbu->bindParam(":o_type", $o_type);
            $ostmsbu->bindParam(":o_mode", $o_mode);
            $ostmsbu->execute();
  echo "<button  class=\"btn btn-danger\" >uninstall</button>" ;
}else{
  echo "no";
}
  ?>
