﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v2.3.x                            ##
##                      http://www.krhost.ga                       ##
##                 e-mail: admin@kariya-host.com                   ##
##                                                                 ##
##                       copyright (c) 2021                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################

header("Location: .../404.php ") ;
  ?>
