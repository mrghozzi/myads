﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v2.3.x                            ##
##                      http://www.krhost.ga                       ##
##                 e-mail: admin@kariya-host.com                   ##
##                                                                 ##
##                       copyright (c) 2021                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################

if($_POST['uninstall']=="uninstall"){
  include_once '../../../dbconfig.php';
  $name      = "Force ads to appear";
  $o_type    = "plugins";

  $stmt=$db_con->prepare("DELETE FROM options WHERE name=:name AND o_type=:o_type ");
	$stmt->execute(array(':name'=>$name,':o_type'=>$o_type));
  $name      = "Force ads to appear";
  $o_type    = "extensions_code";
   $stmt=$db_con->prepare("DELETE FROM options WHERE name=:name AND o_type=:o_type ");
	$stmt->execute(array(':name'=>$name,':o_type'=>$o_type));

  echo "<button  class=\"btn btn-primary\" >install</button>" ;
}else{
  echo "no";
}
  ?>
