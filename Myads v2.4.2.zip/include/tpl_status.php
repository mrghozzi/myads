﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v2.4.x                            ##
##                     http://www.krhost.ga                        ##
##                   e-mail: admin@krhost.ga                       ##
##                                                                 ##
##                       copyright (c) 2022                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################
if($s_st=="buyfgeufb"){

 //  Get Browser
include "tpl/tpl_site_stt.php";
include "tpl/tpl_topic_stt.php";
include "tpl/tpl_news_stt.php";
include "tpl/tpl_image_stt.php";
include "tpl/tpl_store_stt.php";

}else{ echo"404"; }
 ?>