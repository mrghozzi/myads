﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v2.x.x                            ##
##                     http://www.krhost.ga                        ##
##                   e-mail: admin@krhost.ga                       ##
##                                                                 ##
##                       copyright (c) 2019                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################

header("Location: ../404.php ") ;
  ?>
