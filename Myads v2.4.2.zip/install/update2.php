﻿ <?php
 require_once '../dbconfig.php';
 
   include "header.php";
    ?>

    <div class="main-content">
		<div class="form">
			<div class="sap_tabs">
				<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">



				        <div class="facts">
					        <div class="register">
                              <h4>Installation has been successfully</h4>
                              <br />
                              <h3><p style='color:#FF0000'>DELETE THE FOLDER "INSTALL" OR CHANGING THE NAME</p></h3>
							        <div class="sign-up">
								        <a href="../index.php" type="next" />Preview Site</a>
                                    </div>
						    </div>
				        </div>

			 	</div>
		    </div>
        </div>
        <div class="right">
			<h4>Update 2</h4>
			<ul>
				<li><p>The last step</p></li>
				<li><p>Hello  in your site</p></li>

			</ul>


		</div>
		<div class="clear"></div>
	</div>



   <?php   include "footer.php";   ?>
