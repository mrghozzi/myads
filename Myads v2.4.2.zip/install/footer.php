<div class="footer">
		<p>Copyright © 2021 All Rights Reserved <a href="http://www.krhost.ga">kariya-host</a></p>
	</div>
</body>
</html>