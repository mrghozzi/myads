﻿<?php
#####################################################################
##                                                                 ##
##                        My ads v1.1. Beta                        ##
##                 http://www.kariya-host.com                      ##
##                 e-mail: admin@kariya-host.com                   ##
##                                                                 ##
##                       copyright (c) 2017                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################

header("Location: ../../404.php ") ;
  ?>
