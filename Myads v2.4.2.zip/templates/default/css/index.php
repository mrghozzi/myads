﻿<?php
header("Location: http://www.kariya-host.com/error.php?404") ; 
  ?>
