<?php if($s_st=="buyfgeufb"){  ?>
<div id="page-wrapper">
			<div class="main-page">
				<div class="four">
					<img src="<?php url_site();  ?>/templates/_panel/images/404.png" alt="" />
					<p>This page does not exist.</p>
					<a href="<?php url_site(); ?>/index.php">Go To Home</a>
				</div>
			</div>	
		</div>
<?php }else{ echo"404"; }  ?>